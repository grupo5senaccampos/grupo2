angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.meuPerfil', {
    url: '/Meu perfil',
    views: {
      'tab4': {
        templateUrl: 'templates/meuPerfil.html',
        controller: 'meuPerfilCtrl'
      }
    }
  })

  .state('tabsController.suasMetas', {
    url: '/Metas',
    views: {
      'tab6': {
        templateUrl: 'templates/suasMetas.html',
        controller: 'suasMetasCtrl'
      }
    }
  })

  .state('tabsController.calendario', {
    url: '/calendario',
    views: {
      'tab5': {
        templateUrl: 'templates/calendario.html',
        controller: 'calendarioCtrl'
      }
    }
  })

  .state('editarPerfil', {
    url: '/editar',
    templateUrl: 'templates/editarPerfil.html',
    controller: 'editarPerfilCtrl'
  })

$urlRouterProvider.otherwise('')


});